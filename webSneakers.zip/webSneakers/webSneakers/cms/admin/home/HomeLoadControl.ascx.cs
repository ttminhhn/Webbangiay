﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webSneakers.cms.admin.home
{
    public partial class HomeLoadControl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //int soLuot = Convert.ToInt32(Application["soluottruycap"]);
            //ltrTruyCap.Text = soLuot.ToString();
        }
    }
}